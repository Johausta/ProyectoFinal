
from cProfile import run
from email.mime import base
from http import server
from msilib.schema import TextStyle
from textwrap import shorten
from tkinter import TOP

import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from dash.dependencies import Input, Output


app = dash.Dash(__name__,)
#app = dash.Dash(__name__)
colors = {
'background': '#B0C4DE',
'text': '#000000'}


pd.options.mode.chained_assignment = None  #Desactivar warnings

BaseData = 'C:/Users/johadercuellar/Desktop/Usta/'

Base=pd.read_excel(BaseData+"sivigila_desnutricion.xlsx")

BaseCor = pd.read_csv(BaseData + "comuna.csv", sep=';', decimal=',')


############ Acumulado de menores según el esquema de vacunación ###########
#*Presentado por Johader Cuellar*

base11 = Base 
base11['esq_vac'] = np.where((base11['esq_vac']== 1), 'Con Esquema de Vacunación', base11['esq_vac'])
base11['esq_vac'] = np.where((base11['esq_vac']== '2'), 'Sin Esquema de Vacunación', base11['esq_vac'])
base11['esq_vac'] = np.where((base11['esq_vac']== '3'), 'No hay Información', base11['esq_vac'])

tab2 = base11['esq_vac'].value_counts().rename_axis('Asignacion').reset_index(name='Menores reportados')

fig_causa=px.pie(tab2,values='Menores reportados',names='Asignacion',
	title='Acumulado de menores según el esquema de vacunación',
	color_discrete_sequence=px.colors.sequential.RdBu)

fig_causa.update_layout(
		plot_bgcolor=colors['background'],
		paper_bgcolor=colors['background'],
		font_color=colors['text'],
        
    )


######### Promedio de edades en las top 10 comunas de Medellín ###########################################################################################################################################
#Presentado por Johader Cuellar*
Basetop = base11.loc[base11["comuna"].isin(['Manrique','Doce de Octubre','Robledo','Villa Hermosa','Popular','San Javier','Aranjuez','Santa Cruz','Belen','Buenos Aires']),]
available_ciudades=Basetop["comuna"].unique()
TabCiudadcausaretra=Basetop.groupby(['comuna'],as_index=False)['edad_'].mean()

fig_retr_ciud=px.bar(TabCiudadcausaretra,x='edad_',y='comuna',color='edad_',title='Edad promedio en meses en el top de las comunas de Medellín',color_discrete_sequence=px.colors.sequential.RdBu_r)

#########################################################################################################################################################################################################

########## Precio Promedio por comuna ######
# *Presentado por Johader Cuellar*

tab=pd.pivot_table(base11,values="peso_nac",index=["comuna"],aggfunc=np.mean,fill_value=0).reset_index()
tab.columns=["Comuna","Peso_Promedio"]

fig_peso = px.line(tab, x='Comuna', y="Peso_Promedio",title="Peso promedio en cada comuna")
fig_peso.update_layout(
		plot_bgcolor=colors['background'],
		paper_bgcolor=colors['background'],
		font_color=colors['text'],
        
    )

#########################################################################################################################################################################################################

######### Promedio de edades en las top 10 comunas de Medellín ###########################################################################################################################################
#Presentado por Johader Cuellar*

Top=pd.DataFrame(base11["comuna"].value_counts(normalize=True)).sort_values(by='comuna',ascending=False).reset_index().head(10)

Top.columns=["Comuna","Porcentaje"]
Basetop=base11.loc[base11["comuna"].isin(Top["Comuna"]),]
Basetop["comuna"]=pd.Categorical(Basetop["comuna"])
a=pd.DataFrame(Basetop.groupby(["comuna","sexo_"],as_index=False)["peso_act"].mean())
b=pd.DataFrame(Basetop.groupby(["comuna","sexo_"],as_index=False)[["talla_nac","talla_act"]].mean())
FBase=a.merge(b,on=["comuna","sexo_"],how="inner")

FBase.columns=["Comuna","Sexo","Peso_Actual","Promedio_TallaNac","Promedio_TallaAct"]

available_estados=FBase["Comuna"].unique()
fig_scatter=px.scatter(FBase,x="Promedio_TallaNac",y="Promedio_TallaAct",size="Peso_Actual",
                       hover_name="Sexo",color="Comuna",title="Tiempo de vuelo Vs Distancia por top 10 Estados")


#########################################################################################################################################################################################################
base12 = pd.merge(Base, BaseCor, left_on=['comuna'], right_on=['comuna'],how='inner' )
px.set_mapbox_access_token("pk.eyJ1IjoicHJvZi10YXRpYW5hLWd1dGllcnJleiIsImEiOiJjbDFlNzduYWwwMTBoM2Rua3dqOXd2bHVjIn0.0UICEqjwrqPwqcg53HY9NA")
fig = px.scatter_mapbox(base12,
                        lat='Longitud ',
                        lon='Latitud',
                        hover_name='Ciudad',
                        zoom=10,
                        color="comuna",
                        size="talla_nac",
                        animation_frame='mes', 
                        center = {"lat": 6.2556, "lon": -75.5507})
Map = fig.update_layout(
		plot_bgcolor=colors['background'],
		paper_bgcolor=colors['background'],
		font_color=colors['text'],
        title_text = 'Proceso de talla en recien nacidos por comuna en Medellín',
		showlegend = True,
		geo = dict(
            scope = 'south america',
            landcolor = 'rgb(217, 217, 217)',
        )
    )
##############################################################################################################################################################################################################


Map.update_layout(
    plot_bgcolor=colors['background'],
    paper_bgcolor=colors['background'],
    font_color=colors['text']
)

app.layout= html.Div(

    children=[
		html.H1(children="Desnutrición en menores de 5 años en Medellín",
			style={'textAlign': 'center'}),
		html.H3(children="Contextualización de la información.",style={'textAlign': 'LEFT'}),
		html.P(children="Se llama desnutrición a un estado patológico de distintos grados de severidad y con diferentes manifestaciones clínicas,"
		"causado por la asimilación deficiente de alimentos por el organismo.", style={'textAlign': 'LEFT'}),
		html.P(children="La desnutrición es un problema de salud que se deriva o se relaciona con diferentes factores tales como la capacidad económica, " 
		" el ámbito social y las políticas públicas, entre otros.", style={'textAlign': 'LEFT'}),
		html.P(children="En caso de no tratarse a tiempo, puede comprometer la vida y la salud de la población en general a corto, mediano y largo plazo.",style={'textAlign': 'LEFT'}),
		html.P(children="Un niño o niña con desnutrición crónica puede tener problemas de aprendizaje en la etapa escolar, sobrepeso, obesidad y enfermedades no transmisibles, "
		"como hipertensión o diabetes en la vida adulta.",style={'textAlign': 'LEFT'}),

		html.P(children="El monitoreo de esta problemática es de gran relevancia, debido a que esto tiene efectos en políticas publicas por el simple hecho de mantener el porvenir "
		"de las personas y sobre todo de los infantes, el estudio para determinar si un infante tiene índices de desnutrición se hacen por medio de mediciones tomando diferentes "
		"parámetros como lo pueden ser la talla, peso, lactancia, edad de gestación, esquema de vacunación, entre otros.",style={'textAlign': 'LEFT'}),

		html.P(children="Este estudio recolecta gran información de la ciudad mostrando indicadores que nos muestran la realidad de esta ciudad, "
		"el estudio esta discriminado por comunas, las cuales es la partición territorial que tiene Medellín.",style={'textAlign': 'LEFT'}),

		html.P(children="Como inicio recolectamos información sobre esta situación y la llevamos a una base de datos donde se evidencia los parámetros que toman el "
		"sector salud a infantes entre el mes 0 hasta el mes 60.",style={'textAlign': 'LEFT'}),

		html.P(children="Por ser una base relacionada con salud presentamos diferentes inconvenientes a la hora de comprender las variables debido a que son muy técnicas, "
		"después de la lectura de dicha información de cálculos, se inicia con las descripciones de las variables tomando un diccionario que nos diga que significa cada variable, "
		"cabe aclarar que esto se hizo con el fin de saber cuáles variables son las que nos ayudan a mostrar por medio de una visualización de datos, la explicación más sencilla "
		"de que está pasando con los niños menores a 5 años.",style={'textAlign': 'LEFT'}),

		html.P(children="La limpieza de datos es importante, debido a que tenemos que comprobar que dichos resultados pueden sesgar los análisis, en ello pueden existir datos perdidos en las variables, "
		"otras  barreras pueden ser que los valores eran demasiado extraños o diferentes, como el peso de un infante que era muy superior al promedio, o pesos que son demasiado bajos para la edad de gestación.",style={'textAlign': 'LEFT'}),

		html.H3(children="Descripción de la extracción, transformación y limpieza de los datos",style={'textAlign': 'LEFT'}),
		html.H4(children="¿Qué?",style={'textAlign': 'LEFT'}),
		html.P(children="La información tomada como base para el desarrollo de este proyecto proviene del reporte que realizaron las IPS de los casos confirmados de desnutrición "
		"aguda en menores de cinco (5) años durante el periodo comprendido entre enero de 2016 y diciembre de 2019."
		" La base de datos contiene 22 variables categóricas y cuantitativas relacionadas de la siguiente manera:",style={'textAlign': 'LEFT'}),
		html.P(children="Diccionario: http://medata.gov.co/dataset/desnutrici%C3%B3n-aguda-en-menores-de-5-a%C3%B1os/resource/4c75dc44-61f5-468a-8604-5a6b0cbd6159#{view-graph:{graphOptions:{hooks:{processOffset:{},bindEvents:{}}}},graphOptions:{hooks:{processOffset:{},bindEvents:{}}}} ",style={'textAlign': 'LEFT'}),
		html.P(children="* Edad: Edad del menor en meses. Variable ordenada cuantitativa secuencial desde 1 hasta 29.",style={'textAlign': 'LEFT'}),
		html.P(children="* Sexo: Sexo del menor. Variable cualitativa ordenada, M si el menor es masculino y F si es femenino.",style={'textAlign': 'LEFT'}),
		html.P(children="* crec_dllo: Controles de crecimiento y desarrollo. Variable ordena cualitativa, 1 si cuenta con controles de desarrollo y 2 si no.",style={'textAlign': 'LEFT'}),
		html.P(children="* esq_vac: Si cuenta o no con esquema de vacunación. Variable de orden cualitativo, 1 si el individuo cuenta con esquema de vacunación, 2 si no y 3 si es desconocido.",style={'textAlign': 'LEFT'}),
		html.P(children="* year_: Año de reporte del caso con diagnóstico de desnutrición aguda. Variable de orden cualitativo y secuencial entre el 2016 y 2019.",style={'textAlign': 'LEFT'}),
		html.P(children="Como información la base cuenta con más información como la comuna donde se realizo el reporte, latitud y longitud, ciudad, talla y pero al nacer, "
		"talla y peso en el momento del reporte y otras columnas que se irán explorando en el siguiente documento. Información de 23 columnas y 1898 datos.",style={'textAlign': 'LEFT'}),
	html.Div([
		html.Div(className='six columns'),
		html.Div([
			html.Table([
				html.Thead(html.Tr([html.Th(col) for col in Base[["semana","edad_","sexo_","comuna","talla_nac","peso_nac","peso_act","talla_act","Ciudad","carne_vac"]].columns])),
				html.Tbody([html.Tr([html.Td(Base.iloc[i][col]) for col in Base[["semana","edad_","sexo_","comuna","talla_nac","peso_nac","peso_act","talla_act","Ciudad","carne_vac"]].columns]) for i in range(min(len(Base), 5))])
				])], className='six columns')], className='row'),

		html.H4(children="¿Por qué?",style={'textAlign': 'LEFT'}),
		html.P(children="Se espera informar las edades segregadas por sexo donde se han reportado más casos de desnutrición en la ciudad de Medellín – Colombia, "
		"para considerar lo importante que el conocimiento de la información y así poder determinar si estas causas pueden afectar negativamente el desarrollo de la ciudad.",style={'textAlign': 'LEFT'}),
		html.H4(children="¿Cómo?",style={'textAlign': 'LEFT'}),
		html.P(children="Se reestructura la base con todas las variables,teniendo en cuenta el crecimiento de desarrollo, edad, sexo, año de reporte, esquema de vacunación, comuna, ciudad y otras.",style={'textAlign': 'LEFT'}),
		html.H5(children="Marcas y Canales.",style={'textAlign': 'LEFT'}),
		html.P(children="* Se consideran las marcas de color para diferenciar las variables de sexo, crecimiento de desarrollo y esquema de vacunación.",style={'textAlign': 'LEFT'}),
		html.P(children="* Marcas de línea para asignar los valores en edades a cada sexo.",style={'textAlign': 'LEFT'}),
		html.P(children="* Canal de posición espacial vertical y horizontal con el fin de realizar representaciones de cantidades de edad y respectivos promedios.",style={'textAlign': 'LEFT'}),
		html.P(children="* Canal de color para realizar separación en sexo. ",style={'textAlign': 'LEFT'}),

		
    # 1era Viz
	html.Div([
		html.Div([
			html.H3(children="Acumulado de menores según el esquema de vacunación."),
            ### Editar Texto
			html.P(children=" Se visualiza elesquema de vacunación, esto por el simple hecho de saber el registro de vacunaciones que tienen los menores en Medellín, "
			"este indicador es importante conocerlo para saber qué porcentaje de la población esta vacunada y con ella mirar si es cierto que se presenta una asociación "
			"con los índices de desnutrición y el esquema de vacunación.",style={'textAlign': 'LEFT'}),
			dcc.Graph(id='first_viz',figure=fig_causa)],className='six columns')]), 
            
            
    # 2da Viz
	html.Div([
		html.Div([
			html.H3(children="Edad Promédio en las comunas de Medellín."),
            ## Cambiar texto
			html.P(children='En las edades promedio se visualiza por medio de un gráfico de barras discriminados por comunas en las que combinamos '
			'junto con un mapa de calor. Aquí se permite conocer cuales comunas tienen el índice de edad promedio relevante y el mas pequeño, '
			'es importante saberlo por comuna para poder hacer una comparación entre las mismas.',style={'textAlign': 'LEFT'}),
			dcc.Checklist(id='checklist_ciudad', 
				options=[{'label': i, 'value': i} for i in available_ciudades], value=['Robledo','Villa Hermosa'],
				labelStyle={'display': 'inline-block'}),
			dcc.Graph(id='second_viz')],className='six columns')]),
    # 4ta Viz
	html.Div([
		html.H3(children="Peso promedio por comuna de los menores."),
		html.P(children="En esta visualización se focaliza a la desnutrición infantil, pero por peso promedio, no es de extrañar que el peso trae consigo diferentes variables, "
		"como lo es alimentación, nivel socioeconómico, bienestar, entre otros. Se puede observar en esta los comportamientos por comunas, en las que los picos altos nos muestran "
		"que mayor nivel socioeconómico que sea el sector, más alto es el promedio de peso de los menores, al contrario, pasa con comunas como el Corregimiento De Santa Elena que por "
		"ser una comuna del norte y consigo un menor nivel socioeconómico, el peso promedio de los infantes son demasiado bajos.",style={'textAlign': 'LEFT'} ), 
		dcc.Graph(id="fourth_viz",figure=fig_peso)],className='six columns'),

	# 5ta Viz
	html.Div([
		html.Div([
			html.H3(children='Peso promedio por niñ@, sexo y comuna.'),
			html.P(children="Se discrimina por sexo, es claro que tantos los niños y niñas al momento de nacer manejan estándares completamente diferentes para saber si el infante "
			"tiene desnutrición o no, es por ello que junto con un este diagrama podemos separar el sexo y mirar cuál es su talla actual y al nacer, con el fin de dar a conocer este "
			"parámetro junto al peso actual en cada comuna.",style={'textAlign': 'LEFT'}),
			dcc.Dropdown(id="crossfilter_estado",options=[{'label': i, 'value': i} for i in available_estados],value='Belen'),
			dcc.Graph(id='fifth_viz')],className='six columns')]),
	# 6ta Viz
	html.Div([
		html.H3(children='Cantidad acumulada de tallas por comunas en Medellín.'),
		html.P(children="Un mapa que nos muestre como se está comportando la medición de talla en los menores de edad es importante, para tener presente en que zonas geográficas se está acumulando, "
		"es decir, si en el norte existe menor o mayor medida de talla, es por ello que junto con el análisis anterior tenemos que comprobar cómo es, pero en términos de meses. "
		"Con el grafico se evidencia que en el norte de Medellín existe tallas de nacidos más bajas en los meses transcurridos, siendo las comunas del norte las más afectadas con "
		"la problemática de desnutrición infantil.",style={'textAlign': 'LEFT'}),
		dcc.Graph(id='sixth viz',figure=Map)],className='six columns'),

	html.Div([
		
		html.Div([
			html.H3('Talla Actual Por Comuna en Medellín'),
		]),

		html.Div([
			html.Div([
				html.P('Selecciones el sexo del Menor', className = 'fix_label', style={'color':'black', 'margin-top': '5px'}),
				dcc.RadioItems(id = 'dosis-radioitems', 
								labelStyle = {'display': 'inline-block'},
								options = [
									{'label' : 'Masculino', 'value' : 'Sexo_M'},
									{'label' : 'Femenino', 'value' : 'Sexo_F'}
								], value = 'Sexo_M',
								style = {'text-aling':'center', 'color':'black'}, className = 'dcc_compon'),
			], className = 'create_container2 five columns', style = {'margin-bottom': '20px'}),
		], className = 'row flex-display'),

		html.Div([
			html.Div([
				dcc.Graph(id = 'my_graph', figure = {})
			], className = 'create_container2 eight columns'),

			html.Div([
				dcc.Graph(id = 'pie_graph', figure = {})
			], className = 'create_container2 five columns')
		], className = 'row flex-display'),

	], id='mainContainer', style={'display':'flex', 'flex-direction':'column'}),
	
	html.Div([
		html.H3(children='Conclusion:',style={'textAlign': 'center'}),
		html.P(children="Este no es un problema de una ciudad sino a nivel mundial, en un mundo con recursos tan grandes, se evidencia con gran asombro la desigualdad"
		" que hay en sectores con grandes cantidades de recursos y otro con pocas,  es importante analizar la información ya que un menor en desnutrición no es un problema "
		"de una familia o persona, de solo una región si no también es un problema de un país, ya que sin menores sanos una nación no puede desarrollarse es donde se debe considerar "
		"que los menores son el futuro en todo lugar que exista.",style={'textAlign': 'LEFT'})]),
	html.Div([
		html.H3(children='InteGrantes: ',style={'textAlign': 'LEFT'}),
		html.P(children="Johader Guillermo Cuellar Medina",style={'textAlign': 'LEFT'}),
		html.P(children="Pryor Jamphiers Epinosa Muñoz",style={'textAlign': 'LEFT'})]),
		
	]
)

@app.callback(
    Output('my_graph', component_property='figure'),
    [Input('dosis-radioitems', component_property='value')])

def update_graph(value):

    if value == 'Sexo_M':
        fig = px.bar(
            data_frame = Base,
            x = 'comuna',
            y = 'Sexo_M')
    else:
        fig = px.bar(
            data_frame= Base,
            x = 'comuna',
            y = 'Sexo_F')
    return fig

@app.callback(
    Output('pie_graph', component_property='figure'),
    [Input('dosis-radioitems', component_property='value')])

def update_graph_pie(value):

    if value == 'Sexo_M':
        fig2 = px.pie(
            data_frame = Base,
            names = 'comuna',
            values = 'Sexo_M')
    else:
        fig2 = px.pie(
            data_frame = Base,
            names = 'comuna',
            values = 'Sexo_F'
        )
    return fig2

## 2da Viz

############### Promedio Por comunas ######################################################################################
@app.callback(
    dash.dependencies.Output('second_viz', 'figure'),
    [dash.dependencies.Input('checklist_ciudad', 'value')])

def update_graph(ciudad_value):
	TabRetraso_ciudad=TabCiudadcausaretra[TabCiudadcausaretra['comuna'].isin(ciudad_value)]
	fig_retr_ciud=px.bar(TabRetraso_ciudad,x='edad_',y='comuna',color='edad_',
		title='Top 10 de ciudades',color_discrete_sequence=px.colors.sequential.RdBu_r)
	return fig_retr_ciud
##########################################################################################################################


## 5ta Viz

@app.callback(
    dash.dependencies.Output('fifth_viz', 'figure'),
    [dash.dependencies.Input('crossfilter_estado', 'value')])

def update_graph(estado_value):
	FBase_est=FBase[FBase["Comuna"]==estado_value]
	fig_sca=px.scatter(FBase_est,x="Promedio_TallaNac",y="Promedio_TallaAct",size="Peso_Actual",
		hover_name="Sexo",title="")
	return fig_sca


if __name__ == "__main__":
    app.run_server(debug=True)